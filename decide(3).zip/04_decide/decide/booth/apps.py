from django.apps import AppConfig


class BoothConfig(AppConfig):
    name = 'booth'
