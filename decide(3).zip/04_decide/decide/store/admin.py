from django.contrib import admin

from .models import Vote


admin.site.register(Vote)
