from django.apps import AppConfig


class VisualizerConfig(AppConfig):
    name = 'visualizer'
